<br>
<br>
<br>
<br>
<br>
<footer class="footer-bottom margin-top-20">
    <p class="text-center">&copy;2020 all rights reserved || Ecommerce site</p>
</footer>