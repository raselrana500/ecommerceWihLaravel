<form class="form-inline" action="<?php echo e(route('carts.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
<button type="button" onClick="addToCart(<?php echo e($product->id); ?>)" class="btn btn-warning"><i class="fa fa-plus"></i> Add to Cart</button>
</form>