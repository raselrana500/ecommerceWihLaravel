            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 margin-bottom-10">
                    <div class="card">
                        <?php $i=1; ?>
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($i > 0): ?>
                                <a href="<?php echo e(route('products.show',$product->slug)); ?>"><img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. $image->image)); ?>" alt="<?php echo e($product->title); ?>"></a>  
                                <?php endif; ?>
                            <?php $i--; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="card-body">
                            <h4 class="card-title">
                                <a style="text-decoration:none;color:#000000;" href="<?php echo e(route('products.show',$product->slug)); ?>"><?php echo e($product->title); ?></a>
                            </h4>
                            <p class="card-text"><strong style="color:red;font-size:20px ;">Price:</strong> <?php echo e($product->price); ?> TK</p>
                            <?php echo $__env->make('frontend.pages.product.partials.cart_button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="paginate mt-4">
                <?php echo e($products->links()); ?>

            </div>