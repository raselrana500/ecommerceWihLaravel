<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <!-- Page Title Header Starts-->
    <div class="card">
      <div class="card-header">
        <strong>Manage Orders</strong> 
      </div>
      <div class="card-body">
        <?php echo $__env->make('backend.partials.messagess', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <table class="table table-bordered table-hover table-striped table-responsive" id="dataTable">
            <thead>
              <tr>
                  <th>#</th>
                  <th>Orderer Id</th>
                  <th>Orderer Name</th>
                  <th>Orderer Phone No</th>
                  <th>Order Status</th>
                  <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($loop->index + 1); ?></td>
                <td>#LE<?php echo e($order->id); ?></td>
                <td><?php echo e($order->name); ?></td>
                <td><?php echo e($order->phone_no); ?></td>
                <td>
                <!-- seen status -->
                  <p>
                    <?php if($order->is_seen_by_admin): ?>
                      <button class="button btn btn-success btn-sm mt-3">Seen</button>
                    <?php else: ?>
                      <button class="button btn btn-danger btn-sm mt-3">Unseen</button>
                    <?php endif; ?>
                  
                  <!-- complete status  -->
                  
                    <?php if($order->is_completed): ?>
                      <button class="button btn btn-success btn-sm mt-3">Completed</button>
                    <?php else: ?>
                      <button class="button btn btn-danger btn-sm mt-3">Not Completed</button>
                    <?php endif; ?>
                  
                  <!-- paid status  -->
                  
                    <?php if($order->is_paid): ?>
                      <button class="button btn btn-success btn-sm mt-3">Paid</button>
                    <?php else: ?>
                      <button class="button btn btn-danger btn-sm mt-3">UnPaid</button>
                    <?php endif; ?>
                  </p>
                </td>
                
                <td>
                  <a class="btn btn-success" href="<?php echo e(route('admin.order.show',$order->id)); ?>">View Order</a>
                  <a class="btn btn-primary" href="<?php echo e(route('admin.pages.category.edit',$order->id)); ?>">Edit</a>
                  <a class="btn btn-danger" href="<?php echo e(route('admin.order.delete',$order->id)); ?>">Delete</a>
                </td>
                 
                  
            </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
   
</div> 
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <?php echo $__env->make('backend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- partial -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>