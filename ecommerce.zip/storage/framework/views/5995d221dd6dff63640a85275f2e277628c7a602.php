<?php $__env->startSection('content'); ?>


<div class="container margin-top-20">
        <div class="row">
                <div class="col-md-4">
                        <?php echo $__env->make('frontend.partials.product_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-8">
                        <div class="widget bg">
                        <h3>All Products</h3>
                        <?php echo $__env->make('frontend.pages.product.partials.all_products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        
                        </div>
                </div>
        </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>