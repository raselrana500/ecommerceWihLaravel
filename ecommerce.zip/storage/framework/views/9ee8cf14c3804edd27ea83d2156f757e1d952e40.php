<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Contact page</h2>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Doloribus saepe illum sed. Eaque dignissimos officiis officia dolore accusantium. Delectus debitis beatae nemo consectetur molestiae rerum soluta error eveniet voluptas voluptate, sed perspiciatis. Eligendi recusandae sint labore voluptas eos dicta itaque alias accusantium ullam repellendus cum nisi dolores dolor ipsa tempora neque nostrum amet cumque consectetur, tempore velit et sed a. Quasi facere dolorum aliquam soluta alias ex, architecto ipsam incidunt quis, excepturi autem culpa odit minus in, qui est at distinctio itaque! Officia dicta minus ex consequatur, vel quae voluptates illum minima? Neque, nisi ut. Adipisci tempore eveniet error quidem.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>