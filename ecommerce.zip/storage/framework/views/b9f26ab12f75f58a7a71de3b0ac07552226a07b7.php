<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <!-- Page Title Header Starts-->
    <Div class="card card-body">
      <h3>Welcome to Admin Pannel</h3>
      <br>
      <br>
      <p><a href="<?php echo e(route('index')); ?>" class="btn btn-primary btn-lg" target="_blank">View Frontend</a></p>
    </Div>
  </div>
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <?php echo $__env->make('backend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- partial -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>