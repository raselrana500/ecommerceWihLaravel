<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <!-- Page Title Header Starts-->
    <div class="card">
      <div class="card-header">
        <strong>View Order #LE<?php echo e($order->id); ?></strong> 
        <a href="<?php echo e(route('admin.order.invoice',$order->id)); ?>" class="btn btn-success">Generate Invoice to pdf</a>
      </div>
      <div class="card-body">
        <?php echo $__env->make('backend.partials.messagess', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <h3>Order Informations</h3>
        <div class="row">
          <div class="col-md-6 border-right">
            <p><strong>Orderer Name : </strong> <?php echo e($order->name); ?> </p>
            <p><strong>Orderer Phone: </strong> <?php echo e($order->phone_no); ?> </p>
            <p><strong>Orderer Email : </strong> <?php echo e($order->email); ?> </p>
            <p><strong>Orderer Shipping Address : </strong> <?php echo e($order->shipping_address); ?> </p>
          </div>
          <div class="col-md-6">
            <p><strong>Order Payment Method : </strong> <?php echo e($order->payment->name); ?> </p>
            <p><strong>Order Payment Transaction Id : </strong> <?php echo e($order->payment->Transaction_id); ?> </p>
          </div>
          <hr>
          <h3>Order Items: </h3>
          <?php if($order->carts->count() > 0): ?>
          <table class="table table-bordered table-stripe" #="dataTable">
          <thead>
              <tr class="table-primary">
                  <th>No.</th>
                  <th>Product Title</th>
                  <th>Product Image</th>
                  <th>Product Quantity</th>
                  <th>Unit Price</th>
                  <th>Sub total Price</th>
                  <th>Action</th>
              </tr>
          </thead>
          <tbody>
              <?php
                  $total_price=0;
              ?>
              <?php $__currentLoopData = $order->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td>
                      <?php echo e($loop->index + 1); ?>

                  </td>
                  <td>
                      <a href="<?php echo e(route('products.show',$cart->product->slug)); ?>"><?php echo e($cart->product->title); ?></a>
                  </td>
                  <td>
                      <?php if($cart->product->images->count() > 0 ): ?>
                          <img src="<?php echo e(asset('public/images/products/'. $cart->product->images->first()->image)); ?>" width="40px">
                      <?php endif; ?>
                  </td>
                  <td>
                      <form class="form-inline" action="<?php echo e(route('carts.update',$cart->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="number" name="product_quantity" value="<?php echo e($cart->product_quantity); ?>" class="form-controll"/>
                          <button type="submit" class="btn btn-primary btn-sm ml-8 ml-2">Update</button>
                      </form>
                  </td>
                  <td>
                      <?php echo e($cart->product->price); ?> Taka
                  </td>
                  <td>
                  
                      <?php
                          $total_price += $cart->product->price * $cart->product_quantity;
                      ?>
                      <?php echo e($cart->product->price * $cart->product_quantity); ?> Taka
                  </td>
                  <td>
                      <form class="form-inline" action="<?php echo e(route('carts.delete',$cart->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="cart_id"/>                        
                          <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td colspan="4">

                  </td>
                  <td style="color:#FF0000;">
                      <h4>Total Amount:</h4>
                  </td>
                  <td style="color:#FF0000;" colspan="2">
                      <h4><?php echo e($total_price); ?> Taka</h4>
                  </td>
              </tr>
          </tbody>
      </table>
      <?php endif; ?>
      <hr>
      <form action="<?php echo e(route('admin.order.completed',$order->id)); ?>" method="post" class="mr-2 mt-2">
        <?php echo csrf_field(); ?>
        <?php if($order->is_completed): ?>
        <input type="submit" value="Cancel Order" class="btn btn-danger">
        <?php else: ?>
        <input type="submit" value="Complete Order" class="btn btn-success">
        <?php endif; ?>
      </form>
      <form action="<?php echo e(route('admin.order.paid',$order->id)); ?>" method="post" class="mr-2 mt-2">
      <?php echo csrf_field(); ?>
      <?php if($order->is_paid): ?>
      <input type="submit" value="Cancel Payment" class="btn btn-danger">
        <?php else: ?>
        <input type="submit" value="Paid Order" class="btn btn-primary">
        <?php endif; ?>
        
      </form>
        </div>
      </div>
      
      <br>
      <form action="<?php echo e(route('admin.order.charge',$order->id)); ?>" method="post" class="form-inline mr-2 mt-2">
        <?php echo csrf_field(); ?>
        <br>
        <label for="" class="mr-2 ml-2 btn btn-info">Shipping Cost</label>
        <input type="number" value="<?php echo e($order->shipping_charge); ?>" name="shipping_charge">
        <br>
        <label for=""class="mr-2 ml-2 btn btn-info">Custom Discount</label>
        <input type="number" value="<?php echo e($order->custom_discount); ?>" name="custom_discount">
        <br>
        <input type="submit" value="Update" class="btn btn-primary ml-2">
      </form>
      <hr>
    </div>
    </div> 
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <?php echo $__env->make('backend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- partial -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>