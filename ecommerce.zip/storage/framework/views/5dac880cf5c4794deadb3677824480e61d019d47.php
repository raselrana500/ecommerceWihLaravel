<div class="list-group">
    <?php $__currentLoopData = App\Models\category::orderBy('name','asc')->where('parent_id',NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="#main-<?php echo e($parentCat->id); ?>" class="list-group-item list-group-item-action" data-toggle="collapse" data-target="#main-<?php echo e($parentCat->id); ?>">
        <img src="<?php echo e(asset('public/images/categories/'. $parentCat->image)); ?>" width="50px">
        <?php echo e($parentCat->name); ?><span style="float:right;font-style:bold;">>></span>
    </a>
    <div class="collapse
        <?php if(Route::is('categories.show')): ?>
            <?php if(App\Models\category::ParentOrNotCategory($parentCat->id,$category->id)): ?>
                show
                <?php endif; ?>
            <?php endif; ?>
    
    " id="main-<?php echo e($parentCat->id); ?>">
        <div class="child-rows" style="padding-left: 20px;border-left: 1px solid #dfdfdf;background: #ffffff;">
            <?php $__currentLoopData = App\Models\category::orderBy('name','asc')->where('parent_id',$parentCat->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('categories.show',$childCat->id)); ?>" style="border-left: 0px!important;" class="list-group-item list-group-item-action
            <?php if(Route::is('categories.show')): ?>
                <?php if($childCat->id == $category->id): ?>
                    active
                <?php endif; ?>
            <?php endif; ?>
            
            ">
                <img src="<?php echo e(asset('public/images/categories/'.$childCat->image)); ?>" width="30px">
                <?php echo e($childCat->name); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>