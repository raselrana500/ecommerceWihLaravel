<?php $__env->startSection('content'); ?>


<div class="container margin-top-20">
            <div class="row">
                <div class="col-md-4">
                    <?php echo $__env->make('frontend.partials.product_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-8">
                    <div class="widget bg">
                        <h3>All Products</h3>
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 margin-bottom-10">
                                <div class="card">
                                    <?php $i=1; ?>
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($i>0): ?>
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. $image->image)); ?>" alt="Card image">  
                                    <?php endif; ?>
                                    <?php $i--; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="card-body">
                                        <h4 class="card-title">
                                            <?php echo e($product->title); ?>

                                        </h4>
                                        <p class="card-text"><strong style="color:red;font-size:20px ;">Price:</strong> <?php echo e($product->price); ?> TK</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>