<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo $__env->yieldContent('title','Laravel Ecommerce Project'); ?>
    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('frontend.partials.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <div class="wrapper">
    
    <?php echo $__env->make('frontend.partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        
        <?php echo $__env->make('Frontend.partials.messagess', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->make('frontend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>

    <?php echo $__env->make('frontend.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>