<?php $__env->startSection('content'); ?>


<div class="container margin-top-20">
    <div class="row">
                    <div class="col-md-4">
                            <?php echo $__env->make('frontend.partials.product_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="col-md-8">
                                <!-- Start Sidebar + Content -->
                        <div class="our-slider">
                                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                        <ol class="carousel-indicators">

                                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->index == 0 ? 'active' : ''); ?>"></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ol>
                                        <div class="carousel-inner">

                                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item <?php echo e($loop->index == 0 ? 'active' : ''); ?>">
                                                <img class="d-block w-100" src="<?php echo e(asset('public/images/sliders/'.$slider->image)); ?>" alt="<?php echo e($slider->title); ?>" />

                                                <div class="carousel-caption d-none d-md-block">
                                                <h5><?php echo e($slider->title); ?></h5>
                                                
                                                <?php if($slider->button_text): ?>
                                                <p>
                                                <a href="<?php echo e($slider->button_link); ?>" target="_blank" class="btn btn-danger"><?php echo e($slider->button_text); ?></a>
                                                </p>
                                                <?php endif; ?>

                                                </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        

                                        </div>
                                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                        </a>
                                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                        </a>
                                        </div>
                                </div>
                            <div class="widget bg mt-4">
                            <h3 style="background:#4ec3c3;color:white;">Featured Products</h3>
                                <?php echo $__env->make('frontend.pages.product.partials.all_products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            
                            </div>
                    </div>
            </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>