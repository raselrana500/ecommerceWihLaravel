<?php $__env->startSection('content'); ?>
<div class="container card card-body mt-4">
    <div class="card card-body">
    
    <h2>Confirm items</h2>
                <hr>
        <div class="row">
            <div class="col-md-7 border-right">
                <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($cart->product->title); ?> - 
                    <strong><?php echo e($cart->product->price); ?> Taka</strong>
                    - <?php echo e($cart->product_quantity); ?> item
                    
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-5">
                <?php 
                    $total_price = 0;
                ?>
                <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total_price += $cart->product->price * $cart->product_quantity;
                    ?>                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p>Total Price : <strong><?php echo e($total_price); ?></strong> Taka</p>
                <p>Shipping Cost : <strong><?php echo e(App\Models\Setting::first()->shipping_cost); ?></strong> Taka</p>
                <p>Total price with shipping cost : <strong><?php echo e($total_price + App\Models\Setting::first()->shipping_cost); ?></strong> Taka</p>

            </div>
        </div>

        <p>
            <a href="<?php echo e(route('carts')); ?>">Change Cart items</a>
        </p>
    </div>
    <div class="card card-body mt-4">
        <h2>Shipping Address</h2>
        <hr>
        <form method="POST" action="<?php echo e(route('checkouts.store')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('Receiver Name(*)')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="Enter Name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::check() ? Auth::user()->first_name.' '.Auth::user()->last_name : ''); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone_no" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('Phone No(*)')); ?></label>

                            <div class="col-md-6">
                                <input id="phone_no" type="text" placeholder="Enter Phone Number" class="form-control<?php echo e($errors->has('phone_no') ? ' is-invalid' : ''); ?>" name="phone_no" value="<?php echo e(Auth::check() ? Auth::user()->phone_no : ''); ?>" required>

                                <?php if($errors->has('phone_no')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" placeholder="Enter your Email Address" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::check() ? Auth::user()->email : ''); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="messege" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('Additional Messege(Optional)')); ?></label>

                            <div class="col-md-6">
                                <textarea id="messege" rows="4" placeholder="Enter your Messege" class="form-control<?php echo e($errors->has('messege') ? ' is-invalid' : ''); ?>" name="messege"></textarea>

                                <?php if($errors->has('messege')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('messege')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="shipping_address" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('shipping Address(*)')); ?></label>

                            <div class="col-md-6">
                                <textarea id="shipping_address" rows="4" placeholder="Enter shipping Address" class="form-control<?php echo e($errors->has('shipping_address') ? ' is-invalid' : ''); ?>" name="shipping_address"><?php echo e(Auth::check() ? Auth::user()->shipping_address : ''); ?></textarea>

                                <?php if($errors->has('shipping_address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('shipping_address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="payment_method" class="col-md-4 col-form-label text-md-right mt-2"><?php echo e(__('Select a payment Method(*)')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="payment_method_id" required id="payments">
                                    <option value="">Select a payment method</option>
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($payment->short_name); ?>"><?php echo e($payment->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($payment->short_name == "cash_in"): ?>
                                        <div id="payment_<?php echo e($payment->short_name); ?>" class="alert alert-success mt-2 hidden text-center">
                                            <h3 style="color:red;">Cash On Delivery</h3>
                                            <hr style="border: 5px solid blue; border-radius: 5px;">
                                            <h4>
                                                For cash on delivery is nothing necessary.
                                                Just click 
                                                <strong>"Order Now"</strong>
                                                 button.
                                                <br>
                                                <small>
                                                    you will get your product in two or three business days.
                                                </small>
                                            </h4>
                                        </div>
                                        <?php else: ?>
                                        <div id="payment_<?php echo e($payment->short_name); ?>" class="hidden text-center alert alert-success mt-2">
                                            <h3 style="color:red;"><strong><?php echo e($payment->name); ?></strong> <small>Payment</small></h3>
                                            <hr style="border: 5px solid blue; border-radius: 5px;">
                                            <p>
                                                <?php echo e($payment->name); ?> Number : <strong style="color:red;"><?php echo e($payment->no); ?></strong>
                                                <br>
                                                Account Type: <strong style="color:blue;"><?php echo e($payment->type); ?></strong>
                                            </p>
                                            <div class="alert alert-success" style="color:blue;">
                                                Please send the <strong style="color:red;">above money</strong> 
                                                to this <strong style="color:red;"><?php echo e($payment->name); ?> Number</strong> and 
                                                write your <strong style="color:red;">transaction id</strong> 
                                                below there. 
                                            </div>                                            
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="text" name="transaction_id" id="transaction_id" class="form-control hidden"  placeholder="Please Enter your Transaction ID">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4 text-center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Order Now')); ?>

                                </button>
                            </div>
                        </div>
                        </div>
                    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('#payments').change(function(){
            $payment_method = $("#payments").val();
            if($payment_method == "cash_in"){
                $("#payment_cash_in").removeClass('hidden');
                $("#payment_bkash").addClass('hidden');
                $("#payment_rocket").addClass('hidden');
                $("#payment_nagad").addClass('hidden');
            }else if($payment_method == "bkash"){
                $("#payment_bkash").removeClass('hidden');
                $("#payment_cash_in").addClass('hidden');
                $("#payment_rocket").addClass('hidden');
                $("#payment_nagad").addClass('hidden');
                $("#transaction_id").removeClass('hidden');
            }else if($payment_method == "rocket"){
                $("#payment_rocket").removeClass('hidden');
                $("#payment_bkash").addClass('hidden');
                $("#payment_cash_in").addClass('hidden');
                $("#payment_nagad").addClass('hidden');
                $("#transaction_id").removeClass('hidden');
            }else if($payment_method == "nagad"){
                $("#payment_nagad").removeClass('hidden');
                $("#payment_rocket").addClass('hidden');
                $("#payment_bkash").addClass('hidden');
                $("#payment_cash_in").addClass('hidden');
                $("#transaction_id").removeClass('hidden');
            }            
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>