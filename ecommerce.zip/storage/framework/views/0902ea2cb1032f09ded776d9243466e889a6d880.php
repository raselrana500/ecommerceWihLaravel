<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <!-- Page Title Header Starts-->
    <div class="card">
      <div class="card-header">
        <strong>Manage brand</strong> 
      </div>
      <div class="card-body">
        <?php echo $__env->make('backend.partials.messagess', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <table class="table table-hover table-striped table-responsive">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Image</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td>
                  <img src="<?php echo e(asset('public/images/brands/'.$row->image)); ?>" alt="images" width="100" />
                </td>
                
                <td><?php echo e($row->description); ?></td>
                
                <td>
                  <a class="btn btn-success" href="">Show</a>
                  <a class="btn btn-info" href="<?php echo e(route('admin.pages.brand.edit',$row->id)); ?>">Edit</a>
                  <a class="btn btn-danger" href="<?php echo e(route('admin.pages.brand.delete',$row->id)); ?>">Delete</a>
                </td>
                 
                  
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
    
    </div> 
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <?php echo $__env->make('backend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- partial -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>