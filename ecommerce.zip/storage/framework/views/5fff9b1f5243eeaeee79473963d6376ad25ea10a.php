<footer class="footer-bottom">
    <p class="text-center">&copy;2020 all rights reserved || Ecommerce site</p>
</footer>