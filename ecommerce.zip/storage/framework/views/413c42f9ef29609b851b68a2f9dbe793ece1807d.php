<?php $__env->startSection('content'); ?>


<div class="container margin-top-20">
            <div class="row">
                <div class="col-md-4">
                    <?php echo $__env->make('partials.product_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-8">
                    <div class="widget bg">
                        <h3>Featured Products</h3>
                        <div class="row">

                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="widget bg">
                        <h3>New Arrival</h3>
                        <div class="row">

                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-bottom-10">
                                <div class="card">
                                    <img class="card-img-top featured-img" src="<?php echo e(asset('public/images/products/'. 'samsung.png')); ?>" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title">Samsung</h4>
                                        <p class="card-text">Taka: 5000</p>
                                        <a href="#" class="btn btn-primary">Add to Cart</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </din>
        </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>