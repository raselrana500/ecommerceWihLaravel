
    <nav class="navbar navbar-expand-lg navbar-dark bg-light navbar-fixted sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('index')); ?>">

            <img src="<?php echo e(asset('public/images/logo.png')); ?>" width="200px">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent"  style="margin-top:20px;">
                <ul class="navbar-nav me-auto">
                    <!-- <li class="nav-item <?php echo e(route::is('index') ? 'active' : ''); ?>">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('index')); ?>">Home</a>
                    </li> -->
                    <li class="nav-item <?php echo e(route::is('products') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('products')); ?>"  style="color:white;">All Products</a>
                    </li>
                    </li>
                    <li class="nav-item <?php echo e(route::is('contact') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>" style="color:white;">Contact</a>
                    </li>
                    <li class="nav-item" style="padding-left:100px;">
                        <form class="d-flex" action="<?php echo e(route('search')); ?>" method="get">
                            <!-- <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                                <button class="btn btn-outline-success" type="submit">Search</button> -->
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="search" placeholder="Search Product">
                                <div class="input-group-append">
                                    <button class="btn btn-success" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </li>
                    


                </ul>
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                        <a href="<?php echo e(route('carts')); ?>">
                            <button class="btn btn-warning">
                                <span class="badge alert-warning" id="totalItems">
                                    <?php echo e(App\Models\Cart::totalItems()); ?>

                                </span>
                                <span>
                                <i class="fa fa-shopping-cart" style="color:#ffffff;"></i>
                                </span>
                            </button>
                        </a>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link ml-2" href="<?php echo e(route('login')); ?>" style="color:white;"><?php echo e(__('Login')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ml-2" href="<?php echo e(route('register')); ?>" style="color:white;"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <img src="<?php echo e(App\Helpers\ImageHelper::getAvatarImage(Auth::user()->id)); ?>" class="img rounded-circle" style="width:30px;height:30px;" />
                            <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            
                        <a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">
                                <?php echo e(__('My Dashboard')); ?>

                            </a>    
                        
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>

            </div>
        </div>
    </nav>